﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HoangThanhTra_1150080120_BTuan8
{
    public partial class Form3 : Form
    {
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        SqlConnection sqlCon = null;

        public Form3()
        {
            InitializeComponent();
        }

        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            lsvDanhSach.View = View.Details;
            lsvDanhSach.FullRowSelect = true;
            lsvDanhSach.GridLines = true;
            lsvDanhSach.Columns.Add("Mã Sách", 80);
            lsvDanhSach.Columns.Add("Tên Sách", 150);
            lsvDanhSach.Columns.Add("Tác Giả", 120);
            lsvDanhSach.Columns.Add("Năm XB", 100);
            lsvDanhSach.Columns.Add("Mã XB", 80);
            lsvDanhSach.Columns.Add("Ghi chú", 150);

            LoadComboBoxNXB();
            HienThiDanhSachSach();
        }

        private void LoadComboBoxNXB()
        {
            try
            {
                MoKetNoi();
                SqlDataAdapter da = new SqlDataAdapter("SELECT MaXB, TenXB FROM NhaXuatBan", sqlCon);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cboMaXB.DataSource = dt;
                cboMaXB.DisplayMember = "TenXB";
                cboMaXB.ValueMember = "MaXB";
            }
            finally
            {
                DongKetNoi();
            }
        }

        private void HienThiDanhSachSach()
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand(
                    "SELECT MaSach, TenSach, TacGia, NamXB, MaXB, GhiChu FROM Sach", sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lsvDanhSach.Items.Clear();
                while (reader.Read())
                {
                    ListViewItem lvi = new ListViewItem(reader["MaSach"].ToString());
                    lvi.SubItems.Add(reader["TenSach"].ToString());
                    lvi.SubItems.Add(reader["TacGia"].ToString());
                    lvi.SubItems.Add(Convert.ToDateTime(reader["NamXB"]).ToShortDateString());
                    lvi.SubItems.Add(reader["MaXB"].ToString());
                    lvi.SubItems.Add(reader["GhiChu"].ToString());
                    lsvDanhSach.Items.Add(lvi);
                }
                reader.Close();
            }
            finally
            {
                DongKetNoi();
            }
        }

        private void btnThemDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "INSERT INTO Sach VALUES (@MaSach, @TenSach, @TacGia, @NamXB, @MaXB, @GhiChu)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSach", txtMaSach.Text);
                cmd.Parameters.AddWithValue("@TenSach", txtTenSach.Text);
                cmd.Parameters.AddWithValue("@TacGia", txtTacGia.Text);
                cmd.Parameters.AddWithValue("@NamXB", dtpNamXB.Value);
                cmd.Parameters.AddWithValue("@MaXB", cboMaXB.SelectedValue);
                cmd.Parameters.AddWithValue("@GhiChu", txtGhiChu.Text);

                int rows = cmd.ExecuteNonQuery();
                MessageBox.Show(rows > 0 ? "✅ Thêm thành công!" : "⚠️ Thêm thất bại!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
                HienThiDanhSachSach();
            }
        }

        private void btnSuaDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "UPDATE Sach SET TenSach=@TenSach, TacGia=@TacGia, NamXB=@NamXB, MaXB=@MaXB, GhiChu=@GhiChu WHERE MaSach=@MaSach";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSach", txtMaSach.Text);
                cmd.Parameters.AddWithValue("@TenSach", txtTenSach.Text);
                cmd.Parameters.AddWithValue("@TacGia", txtTacGia.Text);
                cmd.Parameters.AddWithValue("@NamXB", dtpNamXB.Value);
                cmd.Parameters.AddWithValue("@MaXB", cboMaXB.SelectedValue);
                cmd.Parameters.AddWithValue("@GhiChu", txtGhiChu.Text);

                int rows = cmd.ExecuteNonQuery();
                MessageBox.Show(rows > 0 ? "✏️ Cập nhật thành công!" : "⚠️ Không tìm thấy mã sách!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
                HienThiDanhSachSach();
            }
        }

        private void btnXoaDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "DELETE FROM Sach WHERE MaSach=@MaSach";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaSach", txtMaSach.Text);

                int rows = cmd.ExecuteNonQuery();
                MessageBox.Show(rows > 0 ? "🗑️ Xóa thành công!" : "⚠️ Không tìm thấy mã sách!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
                HienThiDanhSachSach();
            }
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count > 0)
            {
                ListViewItem lvi = lsvDanhSach.SelectedItems[0];
                txtMaSach.Text = lvi.SubItems[0].Text;
                txtTenSach.Text = lvi.SubItems[1].Text;
                txtTacGia.Text = lvi.SubItems[2].Text;
                dtpNamXB.Value = Convert.ToDateTime(lvi.SubItems[3].Text);
                cboMaXB.Text = lvi.SubItems[4].Text;
                txtGhiChu.Text = lvi.SubItems[5].Text;
            }
        }
    }
}
