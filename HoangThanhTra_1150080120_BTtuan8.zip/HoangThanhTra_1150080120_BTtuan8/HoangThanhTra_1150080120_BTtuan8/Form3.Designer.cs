﻿namespace HoangThanhTra_1150080120_BTuan8
{
    partial class Form3
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lsvDanhSach = new System.Windows.Forms.ListView();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.cboMaXB = new System.Windows.Forms.ComboBox();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnThemDL = new System.Windows.Forms.Button();
            this.btnSuaDL = new System.Windows.Forms.Button();
            this.btnXoaDL = new System.Windows.Forms.Button();
            this.lblMaSach = new System.Windows.Forms.Label();
            this.lblTenSach = new System.Windows.Forms.Label();
            this.lblTacGia = new System.Windows.Forms.Label();
            this.lblNamXB = new System.Windows.Forms.Label();
            this.lblMaXB = new System.Windows.Forms.Label();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.dtpNamXB = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lsvDanhSach
            // 
            this.lsvDanhSach.FullRowSelect = true;
            this.lsvDanhSach.GridLines = true;
            this.lsvDanhSach.HideSelection = false;
            this.lsvDanhSach.Location = new System.Drawing.Point(30, 280);
            this.lsvDanhSach.Name = "lsvDanhSach";
            this.lsvDanhSach.Size = new System.Drawing.Size(720, 230);
            this.lsvDanhSach.TabIndex = 0;
            this.lsvDanhSach.UseCompatibleStateImageBehavior = false;
            this.lsvDanhSach.View = System.Windows.Forms.View.Details;
            this.lsvDanhSach.SelectedIndexChanged += new System.EventHandler(this.lsvDanhSach_SelectedIndexChanged);
            // 
            // txtMaSach
            // 
            this.txtMaSach.Location = new System.Drawing.Point(150, 25);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(400, 22);
            this.txtMaSach.TabIndex = 1;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(150, 65);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(400, 22);
            this.txtTenSach.TabIndex = 2;
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(150, 105);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(400, 22);
            this.txtTacGia.TabIndex = 3;
            // 
            // cboMaXB
            // 
            this.cboMaXB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMaXB.Location = new System.Drawing.Point(150, 185);
            this.cboMaXB.Name = "cboMaXB";
            this.cboMaXB.Size = new System.Drawing.Size(400, 24);
            this.cboMaXB.TabIndex = 5;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(150, 225);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(400, 22);
            this.txtGhiChu.TabIndex = 6;
            // 
            // btnThemDL
            // 
            this.btnThemDL.Location = new System.Drawing.Point(649, 28);
            this.btnThemDL.Name = "btnThemDL";
            this.btnThemDL.Size = new System.Drawing.Size(80, 30);
            this.btnThemDL.TabIndex = 7;
            this.btnThemDL.Text = "Thêm";
            this.btnThemDL.Click += new System.EventHandler(this.btnThemDL_Click);
            // 
            // btnSuaDL
            // 
            this.btnSuaDL.Location = new System.Drawing.Point(649, 101);
            this.btnSuaDL.Name = "btnSuaDL";
            this.btnSuaDL.Size = new System.Drawing.Size(80, 30);
            this.btnSuaDL.TabIndex = 8;
            this.btnSuaDL.Text = "Sửa";
            this.btnSuaDL.Click += new System.EventHandler(this.btnSuaDL_Click);
            // 
            // btnXoaDL
            // 
            this.btnXoaDL.Location = new System.Drawing.Point(649, 181);
            this.btnXoaDL.Name = "btnXoaDL";
            this.btnXoaDL.Size = new System.Drawing.Size(80, 30);
            this.btnXoaDL.TabIndex = 9;
            this.btnXoaDL.Text = "Xóa";
            this.btnXoaDL.Click += new System.EventHandler(this.btnXoaDL_Click);
            // 
            // lblMaSach
            // 
            this.lblMaSach.Location = new System.Drawing.Point(60, 28);
            this.lblMaSach.Name = "lblMaSach";
            this.lblMaSach.Size = new System.Drawing.Size(100, 23);
            this.lblMaSach.TabIndex = 10;
            this.lblMaSach.Text = "Mã Sách:";
            // 
            // lblTenSach
            // 
            this.lblTenSach.Location = new System.Drawing.Point(60, 68);
            this.lblTenSach.Name = "lblTenSach";
            this.lblTenSach.Size = new System.Drawing.Size(100, 23);
            this.lblTenSach.TabIndex = 11;
            this.lblTenSach.Text = "Tên Sách:";
            // 
            // lblTacGia
            // 
            this.lblTacGia.Location = new System.Drawing.Point(60, 108);
            this.lblTacGia.Name = "lblTacGia";
            this.lblTacGia.Size = new System.Drawing.Size(100, 23);
            this.lblTacGia.TabIndex = 12;
            this.lblTacGia.Text = "Tác Giả:";
            // 
            // lblNamXB
            // 
            this.lblNamXB.Location = new System.Drawing.Point(60, 148);
            this.lblNamXB.Name = "lblNamXB";
            this.lblNamXB.Size = new System.Drawing.Size(100, 23);
            this.lblNamXB.TabIndex = 13;
            this.lblNamXB.Text = "Năm XB:";
            // 
            // lblMaXB
            // 
            this.lblMaXB.Location = new System.Drawing.Point(60, 188);
            this.lblMaXB.Name = "lblMaXB";
            this.lblMaXB.Size = new System.Drawing.Size(100, 23);
            this.lblMaXB.TabIndex = 14;
            this.lblMaXB.Text = "Nhà XB:";
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.Location = new System.Drawing.Point(60, 228);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(100, 23);
            this.lblGhiChu.TabIndex = 15;
            this.lblGhiChu.Text = "Ghi chú:";
            // 
            // dtpNamXB
            // 
            this.dtpNamXB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNamXB.Location = new System.Drawing.Point(150, 145);
            this.dtpNamXB.Name = "dtpNamXB";
            this.dtpNamXB.Size = new System.Drawing.Size(400, 22);
            this.dtpNamXB.TabIndex = 4;
            // 
            // Form3
            // 
            this.ClientSize = new System.Drawing.Size(780, 540);
            this.Controls.Add(this.lsvDanhSach);
            this.Controls.Add(this.txtMaSach);
            this.Controls.Add(this.txtTenSach);
            this.Controls.Add(this.txtTacGia);
            this.Controls.Add(this.dtpNamXB);
            this.Controls.Add(this.cboMaXB);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.btnThemDL);
            this.Controls.Add(this.btnSuaDL);
            this.Controls.Add(this.btnXoaDL);
            this.Controls.Add(this.lblMaSach);
            this.Controls.Add(this.lblTenSach);
            this.Controls.Add(this.lblTacGia);
            this.Controls.Add(this.lblNamXB);
            this.Controls.Add(this.lblMaXB);
            this.Controls.Add(this.lblGhiChu);
            this.Name = "Form3";
            this.Text = "THỰC HÀNH 3 - QUẢN LÝ SÁCH";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.ListView lsvDanhSach;
        private System.Windows.Forms.TextBox txtMaSach;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.TextBox txtTacGia;
        private System.Windows.Forms.ComboBox cboMaXB;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnThemDL;
        private System.Windows.Forms.Button btnSuaDL;
        private System.Windows.Forms.Button btnXoaDL;
        private System.Windows.Forms.Label lblMaSach;
        private System.Windows.Forms.Label lblTenSach;
        private System.Windows.Forms.Label lblTacGia;
        private System.Windows.Forms.Label lblNamXB;
        private System.Windows.Forms.Label lblMaXB;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.DateTimePicker dtpNamXB;
    }
}
