﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HoangThanhTra_1150080120_BTuan8
{
    public partial class Form1 : Form  
    {
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // ====== 1. Hàm mở kết nối ======
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // ====== 2. Hàm đóng kết nối ======
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ====== 3. Hiển thị danh sách Nhà xuất bản ======
        private void HienThiDanhSachXB()
        {
            MoKetNoi();
            SqlCommand cmd = new SqlCommand("SELECT MaXB, TenXB, DiaChi FROM NhaXuatBan", sqlCon);
            SqlDataReader reader = cmd.ExecuteReader();


            lsvDanhSach.Items.Clear();
            while (reader.Read())
            {
                string maXB = reader.GetString(0);
                string tenXB = reader.GetString(1);
                string diaChi = reader.GetString(2);

                ListViewItem lvi = new ListViewItem(maXB);
                lvi.SubItems.Add(tenXB);
                lvi.SubItems.Add(diaChi);
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        // ====== 4. Form Load ======
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSachXB();
        }

        // ====== 5. Thêm dữ liệu ======
        private void btnThemDL_Click(object sender, EventArgs e)
        {
            MoKetNoi();
            SqlCommand cmd = new SqlCommand("ThemDuLieu", sqlCon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@maXB", txtMaXB.Text.Trim()));
            cmd.Parameters.Add(new SqlParameter("@tenXB", txtTenXB.Text.Trim()));
            cmd.Parameters.Add(new SqlParameter("@diaChi", txtDiaChi.Text.Trim()));

            int kq = cmd.ExecuteNonQuery();
            if (kq > 0)
            {
                MessageBox.Show("Thêm dữ liệu thành công!");
                HienThiDanhSachXB();
                txtMaXB.Clear(); txtTenXB.Clear(); txtDiaChi.Clear();
            }
        }

        // ====== 6. Sửa dữ liệu ======
        private void btnSuaDL_Click(object sender, EventArgs e)
        {
            MoKetNoi();
            SqlCommand cmd = new SqlCommand("SuaDuLieu", sqlCon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@maXB", txtMaXB.Text.Trim()));
            cmd.Parameters.Add(new SqlParameter("@tenXB", txtTenXB.Text.Trim()));
            cmd.Parameters.Add(new SqlParameter("@diaChi", txtDiaChi.Text.Trim()));

            int kq = cmd.ExecuteNonQuery();
            if (kq > 0)
            {
                MessageBox.Show("Cập nhật thành công!");
                HienThiDanhSachXB();
            }
        }

        // ====== 7. Xóa dữ liệu ======
        private void btnXoaDL_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn xóa?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand("XoaDuLieu", sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@maXB", txtMaXB.Text.Trim()));

                int kq = cmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("Xóa thành công!");
                    HienThiDanhSachXB();
                }
            }
        }
    }
}
