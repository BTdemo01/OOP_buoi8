﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HoangThanhTra_1150080120_BTuan8
{
    public partial class Form2 : Form
    {
        // ===== 1. Chuỗi kết nối CSDL =====
        string strCon = @"Data Source=DESKTOP-O5A1RCH\THANHTRA;
                          Initial Catalog=QuanLyBanSach;
                          Integrated Security=True;
                          Encrypt=False;
                          TrustServerCertificate=True;";

        SqlConnection sqlCon = null;

        // ===== 2. Hàm mở kết nối =====
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // ===== 3. Hàm đóng kết nối =====
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ===== 4. Khởi tạo Form =====
        public Form2()
        {
            InitializeComponent();
        }

        // ===== 5. Hiển thị danh sách Nhà Xuất Bản =====
        private void HienThiDanhSachXB()
        {
            try
            {
                MoKetNoi();
                SqlCommand cmd = new SqlCommand("SELECT MaXB, TenXB, DiaChi FROM NhaXuatBan", sqlCon);
                SqlDataReader reader = cmd.ExecuteReader();

                lsvDanhSach.Items.Clear();
                while (reader.Read())
                {
                    ListViewItem lvi = new ListViewItem(reader["MaXB"].ToString());
                    lvi.SubItems.Add(reader["TenXB"].ToString());
                    lvi.SubItems.Add(reader["DiaChi"].ToString());
                    lsvDanhSach.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // ===== 6. Sự kiện khi Form load =====
        private void Form2_Load(object sender, EventArgs e)
        {
            // Cấu hình ListView
            lsvDanhSach.View = View.Details;
            lsvDanhSach.FullRowSelect = true;
            lsvDanhSach.GridLines = true;

            lsvDanhSach.Columns.Add("Mã XB", 100);
            lsvDanhSach.Columns.Add("Tên XB", 200);
            lsvDanhSach.Columns.Add("Địa chỉ", 250);

            HienThiDanhSachXB();
        }

        // ===== 7. Nút Thêm =====
        private void btnThemDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "INSERT INTO NhaXuatBan VALUES (@MaXB, @TenXB, @DiaChi)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaXB", txtMaXB.Text);
                cmd.Parameters.AddWithValue("@TenXB", txtTenXB.Text);
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);

                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                    MessageBox.Show("✅ Thêm dữ liệu thành công!");
                else
                    MessageBox.Show("⚠️ Thêm thất bại!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
                HienThiDanhSachXB();
            }
        }

        // ===== 8. Nút Sửa =====
        private void btnSuaDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "UPDATE NhaXuatBan SET TenXB = @TenXB, DiaChi = @DiaChi WHERE MaXB = @MaXB";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaXB", txtMaXB.Text);
                cmd.Parameters.AddWithValue("@TenXB", txtTenXB.Text);
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);

                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                    MessageBox.Show("✏️ Cập nhật thành công!");
                else
                    MessageBox.Show("⚠️ Không tìm thấy Mã XB cần sửa!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
                HienThiDanhSachXB();
            }
        }

        // ===== 9. Nút Xóa =====
        private void btnXoaDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "DELETE FROM NhaXuatBan WHERE MaXB = @MaXB";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@MaXB", txtMaXB.Text);

                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                    MessageBox.Show("🗑️ Xóa thành công!");
                else
                    MessageBox.Show("⚠️ Không tìm thấy Mã XB cần xóa!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
                HienThiDanhSachXB();
            }
        }

        // ===== 10. Khi click vào ListView =====
        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count > 0)
            {
                ListViewItem lvi = lsvDanhSach.SelectedItems[0];
                txtMaXB.Text = lvi.SubItems[0].Text;
                txtTenXB.Text = lvi.SubItems[1].Text;
                txtDiaChi.Text = lvi.SubItems[2].Text;
            }
        }
    }
}
